const kWhite        = 0xffffff
const kSilver       = 0xbbbbbb
const kBlack        = 0x000000
const kGrey         = 0x808080
const kDarkGrey     = 0x404040
const kDarkestGrey  = 0x202020
const kProcess1     = 0xf06020
const kProcess2     = 0x2080f0
const kProcessLow1  = 0xa04020
const kProcessLow2  = 0x2060b0
const kProcess1Text = 0xffc080
const kProcess2Text = 0x80e0ff


var ctx = null
var offs_x = 0
var offs_y = 0
var image_data = null
var data = null
var width = 0
var height = 0
var buf
var buf8
var buf32

function draw_set_context(canvas) {
    console.log("Setting context")
    ctx = canvas.getContext('2d')
    image_data = ctx.getImageData(0, 0, canvas.width, canvas.height)
    data = image_data.data
    width = canvas.width
    height = canvas.height

    buf = new ArrayBuffer(data.length)
    buf8 = new Uint8ClampedArray(buf)
    buf32 = new Uint32Array(buf)
}

function draw_pixel(x, y, color) {
    const idx = (offs_x + x) + (offs_y + y) * width
    buf32[idx] = 0xff0000ff
}

function draw_flip() {
    image_data.data.set(buf32)
    ctx.putImageData(image_data, 0, 0)
}

function draw_rect(x, y, w, h, color) {
    for (var dx = x; dx < x + w; dx++) {
        for (var dy = y; dy < y + h; dy++) {
            draw_pixel(dx, dy, color)
        }
    }
}

function draw_triangles(x, y, w, h, color1, color2) {
    for (dx = 0; dx < w; dx++) {
        for (dy = 0; dy < h; dy++) {
            if (dy < dx) {
                draw_pixel(x + dx, y + dy, color2)
            }
            else {
                draw_pixel(x + dx , y + dy, color1)
            }
        }
    }
}

function draw_translate_to(x, y) {
    offs_x = x
    offs_y = y
}